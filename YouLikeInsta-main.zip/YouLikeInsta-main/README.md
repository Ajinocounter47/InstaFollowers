### Termux Command :
    $ apt update -y && apt upgrade -y
    $ pkg install git
    $ pkg install python3
    $ git clone https://github.com/RozhakXD/YouLikeInsta
    $ cd YouLikeInsta
    $ pip3 install -r requirements.txt
    $ python3 Run.py
